Q-BitX v0.3.3 + inoffizieller Patch (Basis: q-bitx/Source- Commit c8cedfd)

Inhalt
  qbitx, qbitx-cli               Linux x86_64, gebaut auf Ubuntu 24.04
  qbitx-pq-large-utxo-fix.patch  Quellcode-Aenderungen (git apply)
  qbx-migrate.sh                 verschiebt UTXOs einer Legacy-Adresse auf eine dil1-Adresse

Behebt
  - Absturz beim Erstellen von Block-Templates mit Transaktionen im Mempool (ab Hoehe 220000)
  - minutenlange Haenger bei pqsendtoaddress / pqconsolidatelegacy auf grossen Wallets
  - tx-size nach PQ-Witness-Aktivierung: hoechstens 4 Legacy-Inputs pro Transaktion
  - sendtoaddress Fehler -6 bei Dilithium-Inputs
  - Abstuerze bei listdescriptors / encryptwallet mit Legacy-PQ-Adresse

Hinweise
  - Kein offizielles Release, nicht von den Q-BitX-Entwicklern geprueft.
  - Aendert keine Konsens-Regeln.
  - Vor dem Einsatz wallet.dat sichern.
  - Die Programme brauchen libevent, libleveldb, libdb5.3++ und libsqlite3 vom System.
  - Selbst bauen: Patch mit "git apply" einspielen, dann wie im README des Repositorys.
