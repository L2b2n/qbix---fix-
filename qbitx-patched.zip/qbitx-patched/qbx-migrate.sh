#!/bin/bash
set -euo pipefail
CLI=${CLI:-"qbitx-cli"}; FROM=$1; TO=$2; ROUNDS=${3:-1}; PAUSE=${4:-300}
PER_ROUND=128
for r in $(seq 1 "$ROUNDS"); do
  AMOUNT=$($CLI listunspent 1 9999999 "[\"$FROM\"]" | python3 -c '
import json, sys
from decimal import Decimal
n = int(sys.argv[1])
vals = sorted((Decimal(str(u["amount"])) for u in json.load(sys.stdin, parse_float=Decimal)), reverse=True)[:n]
amt = sum(vals) - Decimal("0.02")
print(f"{amt:.8f}" if len(vals) and amt > 0 else "0")' $PER_ROUND)
  if [ "$AMOUNT" = "0" ]; then echo "round $r: nothing left to move"; break; fi
  echo "round $r: sending $AMOUNT"
  $CLI pqsendtoaddress "$FROM" "$TO" "$AMOUNT" low | grep -E '"tx_count"|"total_sent"|"total_fee"'
  if [ "$r" -lt "$ROUNDS" ]; then sleep "$PAUSE"; fi
done
